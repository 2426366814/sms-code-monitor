<?php
/**
 * 监控项模型类
 * 用于处理监控项相关的数据操作
 */

require_once __DIR__ . '/BaseModel.php';
require_once __DIR__ . '/../utils/Database.php';

class MonitorModel extends BaseModel {
    protected $table = 'monitors';
    
    /**
     * 根据用户ID获取监控项列表
     * @param int $userId
     * @param