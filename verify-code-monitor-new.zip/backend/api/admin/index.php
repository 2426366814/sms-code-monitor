<?php
/**
 * 管理员API
 * 用于管理用户和系统设置
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 加载配置文件
require_once '../../config/config.php';
require_once '../../utils/Database.php';
require_once '../../utils/JWT.php';
require_once '../../utils/Response.php';
require_once '../../models/UserModel.php';

// 初始化响应对象
$response = new Response();

// 获取请求方法
$method = $_SERVER['REQUEST_METHOD'];

// 获取请求路径
$path = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
$path = trim($path, '/');
$parts = explode('/', $path);

// 初始化数据库连接
$config = require '../../config/config.php';
$database = new Database($config['database']);
$userModel = new UserModel($database);
$jwt = new JWT($config['jwt']['secret'], $config['jwt']['algorithm']);

// 验证用户认证
function verifyAuth($jwt, $response) {
    $authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
    if (empty($authHeader)) {
        $response->error('缺少认证令牌', 401);
        return false;
    }

    $token = str_replace('Bearer ', '', $authHeader);
    if (empty($token)) {
        $response->error('无效的认证令牌', 401);
        return false;
    }

    try {
        $payload = $jwt->validateToken($token);
        if (!$payload) {
            $response->error('无效的认证令牌', 401);
            return false;
        }
        return $payload;
    } catch (Exception $e) {
        $response->error('认证失败: ' . $e->getMessage(), 500);
        return false;
    }
}

// 验证管理员权限
function verifyAdmin($userModel, $userId, $response) {
    // 这里简化处理，实际项目中应该检查用户角色
    // 暂时只允许ID为1的用户作为管理员
    if ($userId != 1) {
        $response->error('无管理员权限', 403);
        return false;
    }
    return true;
}

// 处理不同的API端点
switch ($method) {
    case 'GET':
        // 获取用户列表或单个用户
        $payload = verifyAuth($jwt, $response);
        if (!$payload) {
            return;
        }
        if (!verifyAdmin($userModel, $payload['user_id'], $response)) {
            return;
        }
        
        if (isset($parts[0]) && $parts[0] === 'users') {
            if (isset($parts[1])) {
                // 获取单个用户
                getUser($parts[1], $userModel, $response);
            } else {
                // 获取用户列表
                getUsers($userModel, $response);
            }
        } else {
            $response->error('无效的API端点', 404);
        }
        break;
    
    case 'POST':
        // 添加用户或重置密码
        $payload = verifyAuth($jwt, $response);
        if (!$payload) {
            return;
        }
        if (!verifyAdmin($userModel, $payload['user_id'], $response)) {
            return;
        }
        
        if (isset($parts[0]) && $parts[0] === 'users') {
            if (isset($parts[1]) && isset($parts[2]) && $parts[2] === 'reset-password') {
                // 重置用户密码
                resetPassword($parts[1], $userModel, $response);
            } else {
                // 添加用户
                addUser($userModel, $response);
            }
        } else {
            $response->error('无效的API端点', 404);
        }
        break;
    
    case 'PUT':
        // 更新用户
        $payload = verifyAuth($jwt, $response);
        if (!$payload) {
            return;
        }
        if (!verifyAdmin($userModel, $payload['user_id'], $response)) {
            return;
        }
        
        if (isset($parts[0]) && $parts[0] === 'users' && isset($parts[1])) {
            // 更新用户
            updateUser($parts[1], $userModel, $response);
        } else {
            $response->error('无效的API端点', 404);
        }
        break;
    
    case 'DELETE':
        // 删除用户
        $payload = verifyAuth($jwt, $response);
        if (!$payload) {
            return;
        }
        if (!verifyAdmin($userModel, $payload['user_id'], $response)) {
            return;
        }
        
        if (isset($parts[0]) && $parts[0] === 'users' && isset($parts[1])) {
            // 删除用户
            deleteUser($parts[1], $userModel, $response);
        } else {
            $response->error('无效的API端点', 404);
        }
        break;
    
    default:
        $response->error('不支持的请求方法', 405);
        break;
}

/**
 * 获取用户列表
 * @param UserModel $userModel 用户模型
 * @param Response $response 响应对象
 */
function getUsers($userModel, $response) {
    try {
        // 获取查询参数
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $status = isset($_GET['status']) ? $_GET['status'] : '';
        
        // 计算偏移量
        $offset = ($page - 1) * $limit;
        
        // 获取用户列表
        $users = $userModel->getUsers($status, $limit, $offset);
        
        // 获取总数
        $total = $userModel->getUserCount($status);
        
        // 返回响应
        $response->success([
            'list' => $users,
            'total' => $total,
            'page' => $page,
            'limit' => $limit
        ], '获取成功');
        
    } catch (Exception $e) {
        $response->error('获取用户列表失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 获取单个用户
 * @param string $userId 用户ID
 * @param UserModel $userModel 用户模型
 * @param Response $response 响应对象
 */
function getUser($userId, $userModel, $response) {
    try {
        // 获取用户信息
        $user = $userModel->getUserById($userId);
        if (!$user) {
            $response->error('用户不存在', 404);
            return;
        }
        
        // 返回响应
        $response->success($user, '获取成功');
        
    } catch (Exception $e) {
        $response->error('获取用户信息失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 添加用户
 * @param UserModel $userModel 用户模型
 * @param Response $response 响应对象
 */
function addUser($userModel, $response) {
    try {
        // 获取请求数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证请求数据
        if (!isset($data['username']) || !isset($data['email']) || !isset($data['password'])) {
            $response->error('缺少必要的用户信息', 400);
            return;
        }
        
        if (empty($data['username']) || empty($data['email']) || empty($data['password'])) {
            $response->error('用户名、邮箱和密码不能为空', 400);
            return;
        }
        
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $response->error('邮箱格式不正确', 400);
            return;
        }
        
        if (strlen($data['password']) < 6) {
            $response->error('密码长度不能少于6位', 400);
            return;
        }
        
        // 检查用户名是否已存在
        if ($userModel->getUserByUsername($data['username'])) {
            $response->error('用户名已存在', 400);
            return;
        }
        
        // 检查邮箱是否已存在
        if ($userModel->getUserByEmail($data['email'])) {
            $response->error('邮箱已被注册', 400);
            return;
        }
        
        // 创建用户
        $userId = $userModel->createUser([
            'username' => $data['username'],
            'email' => $data['email'],
            'password' => password_hash($data['password'], PASSWORD_DEFAULT),
            'status' => isset($data['status']) ? $data['status'] : 'active'
        ]);
        
        if (!$userId) {
            $response->error('用户创建失败', 500);
            return;
        }
        
        // 获取创建的用户信息
        $user = $userModel->getUserById($userId);
        if (!$user) {
            $response->error('用户创建失败', 500);
            return;
        }
        
        // 返回响应
        $response->success($user, '添加成功');
        
    } catch (Exception $e) {
        $response->error('添加用户失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 更新用户
 * @param string $userId 用户ID
 * @param UserModel $userModel 用户模型
 * @param Response $response 响应对象
 */
function updateUser($userId, $userModel, $response) {
    try {
        // 获取请求数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证用户存在
        $user = $userModel->getUserById($userId);
        if (!$user) {
            $response->error('用户不存在', 404);
            return;
        }
        
        // 准备更新数据
        $updateData = [];
        
        // 处理用户名更新
        if (isset($data['username'])) {
            if (empty($data['username'])) {
                $response->error('用户名不能为空', 400);
                return;
            }
            
            // 检查用户名是否已存在
            $existingUser = $userModel->getUserByUsername($data['username']);
            if ($existingUser && $existingUser['id'] != $userId) {
                $response->error('用户名已存在', 400);
                return;
            }
            
            $updateData['username'] = $data['username'];
        }
        
        // 处理邮箱更新
        if (isset($data['email'])) {
            if (empty($data['email'])) {
                $response->error('邮箱不能为空', 400);
                return;
            }
            
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                $response->error('邮箱格式不正确', 400);
                return;
            }
            
            // 检查邮箱是否已存在
            $existingUser = $userModel->getUserByEmail($data['email']);
            if ($existingUser && $existingUser['id'] != $userId) {
                $response->error('邮箱已被注册', 400);
                return;
            }
            
            $updateData['email'] = $data['email'];
        }
        
        // 处理状态更新
        if (isset($data['status'])) {
            if (!in_array($data['status'], ['active', 'inactive', 'suspended'])) {
                $response->error('状态值无效', 400);
                return;
            }
            
            $updateData['status'] = $data['status'];
        }
        
        // 检查是否有更新数据
        if (empty($updateData)) {
            $response->error('没有需要更新的数据', 400);
            return;
        }
        
        // 执行更新
        $result = $userModel->updateUser($userId, $updateData);
        if (!$result) {
            $response->error('更新失败', 500);
            return;
        }
        
        // 获取更新后的用户信息
        $updatedUser = $userModel->getUserById($userId);
        
        // 返回响应
        $response->success($updatedUser, '更新成功');
        
    } catch (Exception $e) {
        $response->error('更新用户失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 删除用户
 * @param string $userId 用户ID
 * @param UserModel $userModel 用户模型
 * @param Response $response 响应对象
 */
function deleteUser($userId, $userModel, $response) {
    try {
        // 验证用户存在
        $user = $userModel->getUserById($userId);
        if (!$user) {
            $response->error('用户不存在', 404);
            return;
        }
        
        // 禁止删除管理员账户
        if ($userId == 1) {
            $response->error('禁止删除管理员账户', 403);
            return;
        }
        
        // 删除用户
        $result = $userModel->deleteUser($userId);
        if (!$result) {
            $response->error('删除失败', 500);
            return;
        }
        
        // 返回响应
        $response->success(null, '删除成功');
        
    } catch (Exception $e) {
        $response->error('删除用户失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 重置用户密码
 * @param string $userId 用户ID
 * @param UserModel $userModel 用户模型
 * @param Response $response 响应对象
 */
function resetPassword($userId, $userModel, $response) {
    try {
        // 获取请求数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证用户存在
        $user = $userModel->getUserById($userId);
        if (!$user) {
            $response->error('用户不存在', 404);
            return;
        }
        
        // 验证密码
        if (!isset($data['password']) || empty($data['password'])) {
            $response->error('密码不能为空', 400);
            return;
        }
        
        if (strlen($data['password']) < 6) {
            $response->error('密码长度不能少于6位', 400);
            return;
        }
        
        // 重置密码
        $result = $userModel->updateUser($userId, [
            'password' => password_hash($data['password'], PASSWORD_DEFAULT)
        ]);
        
        if (!$result) {
            $response->error('密码重置失败', 500);
            return;
        }
        
        // 返回响应
        $response->success(null, '密码重置成功');
        
    } catch (Exception $e) {
        $response->error('重置密码失败: ' . $e->getMessage(), 500);
    }
}
?>