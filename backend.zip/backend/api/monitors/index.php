<?php
/**
 * 监控项API
 * 用于管理用户的监控项，包括添加、删除、更新、刷新等操作
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// 加载配置文件
require_once '../../config/config.php';
require_once '../../utils/Database.php';
require_once '../../utils/JWT.php';
require_once '../../utils/Response.php';
require_once '../../models/MonitorModel.php';
require_once '../../models/UserModel.php';

// 初始化响应对象
$response = new Response();

// 获取请求方法
$method = $_SERVER['REQUEST_METHOD'];

// 获取请求路径
$path = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
$path = trim($path, '/');
$parts = explode('/', $path);

// 初始化数据库连接
$config = require '../../config/config.php';
$database = new Database($config['database']);
$monitorModel = new MonitorModel($database);
$userModel = new UserModel($database);
$jwt = new JWT($config['jwt']['secret'], $config['jwt']['algorithm']);

// 验证用户认证
function verifyAuth($jwt, $response) {
    $authHeader = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
    if (empty($authHeader)) {
        $response->error('缺少认证令牌', 401);
        return false;
    }

    $token = str_replace('Bearer ', '', $authHeader);
    if (empty($token)) {
        $response->error('无效的认证令牌', 401);
        return false;
    }

    try {
        $payload = $jwt->validateToken($token);
        if (!$payload) {
            $response->error('无效的认证令牌', 401);
            return false;
        }
        return $payload;
    } catch (Exception $e) {
        $response->error('认证失败: ' . $e->getMessage(), 500);
        return false;
    }
}

// 处理不同的API端点
switch ($method) {
    case 'GET':
        // 获取监控项列表
        $payload = verifyAuth($jwt, $response);
        if (!$payload) {
            return;
        }
        getMonitors($payload, $monitorModel, $response);
        break;
    
    case 'POST':
        // 处理POST请求
        $payload = verifyAuth($jwt, $response);
        if (!$payload) {
            return;
        }
        
        switch ($parts[0] ?? '') {
            case 'batch':
                // 批量添加监控项
                batchAddMonitors($payload, $monitorModel, $response);
                break;
            case 'refresh-all':
                // 刷新所有监控项
                refreshAllMonitors($payload, $monitorModel, $response);
                break;
            default:
                // 添加单个监控项
                addMonitor($payload, $monitorModel, $response);
                break;
        }
        break;
    
    case 'PUT':
        // 更新监控项
        $payload = verifyAuth($jwt, $response);
        if (!$payload) {
            return;
        }
        updateMonitor($payload, $monitorModel, $response);
        break;
    
    case 'DELETE':
        // 删除监控项
        $payload = verifyAuth($jwt, $response);
        if (!$payload) {
            return;
        }
        deleteMonitor($payload, $monitorModel, $response);
        break;
    
    default:
        $response->error('不支持的请求方法', 405);
        break;
}

/**
 * 获取用户监控项列表
 * @param array $payload JWT负载
 * @param MonitorModel $monitorModel 监控项模型
 * @param Response $response 响应对象
 */
function getMonitors($payload, $monitorModel, $response) {
    try {
        // 获取查询参数
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $status = isset($_GET['status']) ? $_GET['status'] : '';
        
        // 计算偏移量
        $offset = ($page - 1) * $limit;
        
        // 获取监控项列表
        $monitors = $monitorModel->getUserMonitors($payload['user_id'], $status, $limit, $offset);
        
        // 获取总数
        $total = $monitorModel->getUserMonitorCount($payload['user_id'], $status);
        
        // 返回响应
        $response->success([
            'list' => $monitors,
            'total' => $total,
            'page' => $page,
            'limit' => $limit
        ], '获取成功');
        
    } catch (Exception $e) {
        $response->error('获取监控项失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 添加监控项
 * @param array $payload JWT负载
 * @param MonitorModel $monitorModel 监控项模型
 * @param Response $response 响应对象
 */
function addMonitor($payload, $monitorModel, $response) {
    try {
        // 获取请求数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证请求数据
        if (!isset($data['phone']) || !isset($data['url'])) {
            $response->error('缺少必要的监控项信息', 400);
            return;
        }
        
        if (empty($data['phone']) || empty($data['url'])) {
            $response->error('手机号和URL不能为空', 400);
            return;
        }
        
        // 创建监控项
        $monitorId = $monitorModel->createMonitor([
            'user_id' => $payload['user_id'],
            'phone' => $data['phone'],
            'url' => $data['url'],
            'status' => 'no-code',
            'last_code' => '',
            'last_extracted_code' => '',
            'code_timestamp' => 0,
            'code_time_str' => '',
            'last_update' => date('Y-m-d H:i:s'),
            'last_update_timestamp' => time() * 1000,
            'message' => ''
        ]);
        
        if (!$monitorId) {
            $response->error('监控项创建失败', 500);
            return;
        }
        
        // 获取创建的监控项
        $monitor = $monitorModel->getMonitorById($monitorId, $payload['user_id']);
        if (!$monitor) {
            $response->error('监控项创建失败', 500);
            return;
        }
        
        // 返回响应
        $response->success($monitor, '添加成功');
        
    } catch (Exception $e) {
        $response->error('添加监控项失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 批量添加监控项
 * @param array $payload JWT负载
 * @param MonitorModel $monitorModel 监控项模型
 * @param Response $response 响应对象
 */
function batchAddMonitors($payload, $monitorModel, $response) {
    try {
        // 获取请求数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证请求数据
        if (!isset($data['monitors']) || !is_array($data['monitors'])) {
            $response->error('缺少监控项数据', 400);
            return;
        }
        
        $monitors = $data['monitors'];
        if (empty($monitors)) {
            $response->error('监控项数据不能为空', 400);
            return;
        }
        
        $successCount = 0;
        $failCount = 0;
        $details = [];
        
        foreach ($monitors as $item) {
            try {
                if (!isset($item['phone']) || !isset($item['url']) || empty($item['phone']) || empty($item['url'])) {
                    $failCount++;
                    $details[] = [
                        'phone' => $item['phone'] ?? '',
                        'status' => 'failed',
                        'error' => '手机号和URL不能为空'
                    ];
                    continue;
                }
                
                // 创建监控项
                $monitorId = $monitorModel->createMonitor([
                    'user_id' => $payload['user_id'],
                    'phone' => $item['phone'],
                    'url' => $item['url'],
                    'status' => 'no-code',
                    'last_code' => '',
                    'last_extracted_code' => '',
                    'code_timestamp' => 0,
                    'code_time_str' => '',
                    'last_update' => date('Y-m-d H:i:s'),
                    'last_update_timestamp' => time() * 1000,
                    'message' => ''
                ]);
                
                if ($monitorId) {
                    $successCount++;
                    $details[] = [
                        'phone' => $item['phone'],
                        'status' => 'success',
                        'monitor_id' => $monitorId
                    ];
                } else {
                    $failCount++;
                    $details[] = [
                        'phone' => $item['phone'],
                        'status' => 'failed',
                        'error' => '创建失败'
                    ];
                }
                
            } catch (Exception $e) {
                $failCount++;
                $details[] = [
                    'phone' => $item['phone'] ?? '',
                    'status' => 'failed',
                    'error' => $e->getMessage()
                ];
            }
        }
        
        // 返回响应
        $response->success([
            'success_count' => $successCount,
            'fail_count' => $failCount,
            'details' => $details
        ], '批量添加成功');
        
    } catch (Exception $e) {
        $response->error('批量添加监控项失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 更新监控项
 * @param array $payload JWT负载
 * @param MonitorModel $monitorModel 监控项模型
 * @param Response $response 响应对象
 */
function updateMonitor($payload, $monitorModel, $response) {
    try {
        // 获取监控项ID
        $monitorId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if (!$monitorId) {
            $response->error('缺少监控项ID', 400);
            return;
        }
        
        // 获取请求数据
        $data = json_decode(file_get_contents('php://input'), true);
        
        // 验证监控项存在且属于当前用户
        $monitor = $monitorModel->getMonitorById($monitorId, $payload['user_id']);
        if (!$monitor) {
            $response->error('监控项不存在或无权限访问', 404);
            return;
        }
        
        // 准备更新数据
        $updateData = [];
        if (isset($data['phone'])) {
            $updateData['phone'] = $data['phone'];
        }
        if (isset($data['url'])) {
            $updateData['url'] = $data['url'];
        }
        if (isset($data['status'])) {
            $updateData['status'] = $data['status'];
        }
        
        if (empty($updateData)) {
            $response->error('没有需要更新的数据', 400);
            return;
        }
        
        // 更新监控项
        $result = $monitorModel->updateMonitor($updateData, $monitorId, $payload['user_id']);
        if (!$result) {
            $response->error('更新失败', 500);
            return;
        }
        
        // 获取更新后的监控项
        $updatedMonitor = $monitorModel->getMonitorById($monitorId, $payload['user_id']);
        
        // 返回响应
        $response->success($updatedMonitor, '更新成功');
        
    } catch (Exception $e) {
        $response->error('更新监控项失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 删除监控项
 * @param array $payload JWT负载
 * @param MonitorModel $monitorModel 监控项模型
 * @param Response $response 响应对象
 */
function deleteMonitor($payload, $monitorModel, $response) {
    try {
        // 获取监控项ID
        $monitorId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if (!$monitorId) {
            $response->error('缺少监控项ID', 400);
            return;
        }
        
        // 验证监控项存在且属于当前用户
        $monitor = $monitorModel->getMonitorById($monitorId, $payload['user_id']);
        if (!$monitor) {
            $response->error('监控项不存在或无权限访问', 404);
            return;
        }
        
        // 删除监控项
        $result = $monitorModel->deleteMonitor($monitorId, $payload['user_id']);
        if (!$result) {
            $response->error('删除失败', 500);
            return;
        }
        
        // 返回响应
        $response->success(null, '删除成功');
        
    } catch (Exception $e) {
        $response->error('删除监控项失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 刷新所有监控项
 * @param array $payload JWT负载
 * @param MonitorModel $monitorModel 监控项模型
 * @param Response $response 响应对象
 */
function refreshAllMonitors($payload, $monitorModel, $response) {
    try {
        // 获取用户所有监控项
        $monitors = $monitorModel->getUserMonitors($payload['user_id']);
        
        $successCount = 0;
        $failCount = 0;
        $details = [];
        
        foreach ($monitors as $monitor) {
            try {
                // 发送请求获取验证码
                $responseData = sendRequest($monitor['url']);
                
                // 提取验证码
                $extracted = extractVerificationCode($responseData, $monitor['phone']);
                
                // 更新监控项状态
                $updateData = [
                    'status' => $extracted['status'],
                    'last_code' => $responseData,
                    'last_extracted_code' => $extracted['code'],
                    'code_timestamp' => $extracted['timestamp'],
                    'code_time_str' => $extracted['time_str'],
                    'last_update' => date('Y-m-d H:i:s'),
                    'last_update_timestamp' => time() * 1000,
                    'message' => $extracted['message']
                ];
                
                $monitorModel->updateMonitor($updateData, $monitor['id'], $payload['user_id']);
                
                $successCount++;
                $details[] = [
                    'monitor_id' => $monitor['id'],
                    'status' => 'success',
                    'code' => $extracted['code']
                ];
                
            } catch (Exception $e) {
                $failCount++;
                $details[] = [
                    'monitor_id' => $monitor['id'],
                    'status' => 'failed',
                    'error' => $e->getMessage()
                ];
            }
        }
        
        // 返回响应
        $response->success([
            'success_count' => $successCount,
            'fail_count' => $failCount,
            'details' => $details
        ], '全部刷新成功');
        
    } catch (Exception $e) {
        $response->error('刷新监控项失败: ' . $e->getMessage(), 500);
    }
}

/**
 * 发送HTTP请求
 * @param string $url 请求URL
 * @return string 响应内容
 */
function sendRequest($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}

/**
 * 提取验证码
 * @param string $response 响应内容
 * @param string $phone 手机号
 * @return array 提取结果
 */
function extractVerificationCode($response, $phone) {
    // 简单的验证码提取逻辑
    // 实际项目中可以使用更复杂的正则表达式或AI提取
    
    // 检查响应是否为空
    if (empty($response)) {
        return [
            'status' => 'error',
            'code' => '',
            'timestamp' => 0,
            'time_str' => '',
            'message' => '无响应内容'
        ];
    }
    
    // 尝试提取6位数字验证码
    if (preg_match('/\b\d{6}\b/', $response, $matches)) {
        return [
            'status' => 'success',
            'code' => $matches[0],
            'timestamp' => time() * 1000,
            'time_str' => date('Y-m-d H:i:s'),
            'message' => '提取成功'
        ];
    }
    
    // 尝试提取4位数字验证码
    if (preg_match('/\b\d{4}\b/', $response, $matches)) {
        return [
            'status' => 'success',
            'code' => $matches[0],
            'timestamp' => time() * 1000,
            'time_str' => date('Y-m-d H:i:s'),
            'message' => '提取成功'
        ];
    }
    
    return [
        'status' => 'no-code',
        'code' => '',
        'timestamp' => 0,
        'time_str' => '',
        'message' => '未找到验证码'
    ];
}
?>