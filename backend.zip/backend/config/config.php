<?php
/**
 * 多用户动态验证码监控系统配置文件
 * 定义数据库连接信息和系统配置
 */

return [
    // 数据库配置
    'database' => [
        'host' => 'localhost',      // 数据库主机地址
        'port' => 3306,             // 数据库端口
        'database' => 'jm',         // 默认数据库名称
        'username' => 'jm',         // 默认数据库用户名
        'password' => 'ck123456@',   // 默认数据库密码
        'charset' => 'utf8mb4',     // 字符集
        'collation' => 'utf8mb4_unicode_ci', // 排序规则
        'prefix' => ''              // 表前缀（可选）
    ],
    
    // JWT配置
    'jwt' => [
        'secret' => 'your_jwt_secret_key', // JWT密钥
        'algorithm' => 'HS256',   // 加密算法
        'expires_in' => 3600,     // 过期时间（秒）
        'refresh_expires_in' => 86400 // 刷新令牌过期时间（秒）
    ],
    
    // 系统配置
    'system' => [
        'name' => '多用户动态验证码监控系统',
        'version' => '1.0.0',
        'default_refresh_interval' => 5, // 默认刷新间隔（秒）
        'max_monitors_per_user' => 100,  // 每用户最大监控项数
        'history_keep_days' => 30,       // 历史记录保留天数
        'login_attempts' => 5,           // 登录尝试次数限制
        'login_lockout_time' => 15,      // 登录锁定时间（分钟）
        'password_min_length' => 6,       // 密码最小长度
        'session_timeout' => 60,          // 会话超时时间（分钟）
        'api_rate_limit' => 100,          // API速率限制
        'api_key_expire_days' => 90,      // API密钥过期天数
    ],
    
    // 日志配置
    'log' => [
        'level' => 'info',  // 日志级别
        'path' => __DIR__ . '/../logs/', // 日志存储路径
    ],
    
    // API配置
    'api' => [
        'prefix' => '/api', // API路径前缀
        'cors' => [
            'enabled' => true,
            'allowed_origins' => ['*'],
            'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
            'allowed_headers' => ['Content-Type', 'Authorization'],
            'max_age' => 86400
        ]
    ]
];
